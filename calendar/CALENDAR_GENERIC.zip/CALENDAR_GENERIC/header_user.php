<header class="main-header">
        <nav class="navbar navbar-static-top">
          <div class="container">
            <div class="navbar-header" style="margin:15px;">
                    <ul class="nav navbar-nav navbar-right">
						
			 


         

                </ul>
                  </div>


            <!-- Navbar Right Menu -->
              <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
   


                </ul>
              </div><!-- /.navbar-custom-menu -->
        </nav>
      </header>
